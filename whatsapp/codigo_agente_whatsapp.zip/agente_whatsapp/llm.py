"""llm.py - Llamada a OpenRouter (chat completions).
Entra: lista de mensajes + herramientas. Sale: el mensaje del asistente (dict).
Endpoint: POST https://openrouter.ai/api/v1/chat/completions, cabecera Authorization: Bearer <clave>.
Prueba: se sustituye 'post' por un falso en tests/ (sin red).
"""
import json
import urllib.request

URL = "https://openrouter.ai/api/v1/chat/completions"


def post_json(url, headers, cuerpo, timeout=60):
    req = urllib.request.Request(url, data=json.dumps(cuerpo).encode("utf-8"), headers=headers, method="POST")
    with urllib.request.urlopen(req, timeout=timeout) as r:
        return json.loads(r.read().decode("utf-8"))


def completar(mensajes, herramientas, cfg, post=post_json):
    cuerpo = {"model": cfg["OPENROUTER_MODEL"], "messages": mensajes,
              "tools": herramientas, "tool_choice": "auto", "temperature": 0.3}
    cab = {"Content-Type": "application/json", "Authorization": "Bearer " + cfg["OPENROUTER_API_KEY"]}
    resp = post(URL, cab, cuerpo)
    return resp["choices"][0]["message"]
