"""memoria.py - Memoria por numero de telefono en SQLite.
Entra: numero, rol (user/assistant) y texto. Sale: los ultimos N mensajes (20 por defecto).
Tambien guarda los ids de mensajes ya procesados (Meta reintenta y no hay que contestar dos veces).
Prueba: tests/test_memoria.py
"""
import sqlite3
import threading


class Memoria:
    def __init__(self, ruta="memoria.db", limite=20):
        self.limite = limite
        self.lock = threading.Lock()
        self.db = sqlite3.connect(ruta, check_same_thread=False)
        self.db.execute("CREATE TABLE IF NOT EXISTS mensajes (id INTEGER PRIMARY KEY AUTOINCREMENT, "
                        "numero TEXT NOT NULL, rol TEXT NOT NULL, texto TEXT NOT NULL)")
        self.db.execute("CREATE TABLE IF NOT EXISTS vistos (wamid TEXT PRIMARY KEY)")
        self.db.commit()

    def anadir(self, numero, rol, texto):
        with self.lock:
            self.db.execute("INSERT INTO mensajes (numero, rol, texto) VALUES (?,?,?)", (numero, rol, texto))
            self.db.commit()

    def ultimos(self, numero, n=None):
        n = n or self.limite
        with self.lock:
            filas = self.db.execute("SELECT rol, texto FROM mensajes WHERE numero=? ORDER BY id DESC LIMIT ?",
                                    (numero, n)).fetchall()
        return [{"role": r, "content": t} for r, t in reversed(filas)]

    def turnos_usuario(self, numero):
        with self.lock:
            return self.db.execute("SELECT COUNT(*) FROM mensajes WHERE numero=? AND rol='user'",
                                   (numero,)).fetchone()[0]

    def ya_visto(self, wamid):
        """True si ya lo habiamos procesado; si no, lo apunta y devuelve False."""
        with self.lock:
            try:
                self.db.execute("INSERT INTO vistos (wamid) VALUES (?)", (wamid,))
                self.db.commit()
                return False
            except sqlite3.IntegrityError:
                return True
