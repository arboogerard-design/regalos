"""Tests sin red: Meta y OpenRouter estan simulados.
Ejecutar desde la carpeta codigo/:  python -m unittest discover -s tests -v
"""
import hashlib
import hmac
import json
import os
import shutil
import sys
import tempfile
import threading
import unittest
import urllib.error
import urllib.request

sys.path.insert(0, os.path.join(os.path.dirname(__file__), ".."))

import agente as ag  # noqa: E402
import meta  # noqa: E402
from agenda import Agenda  # noqa: E402
from memoria import Memoria  # noqa: E402
import servidor  # noqa: E402

AQUI = os.path.join(os.path.dirname(__file__), "..")
CFG = {"VERIFY_TOKEN": "tok", "APP_SECRET": "secreto", "WHATSAPP_TOKEN": "t", "OPENROUTER_API_KEY": "k",
       "OPENROUTER_MODEL": "m/x", "PORT": "0", "GRAPH_VERSION": "v27.0"}


def payload(texto="hola", wamid="wamid.1", numero="34600000000", tipo="text"):
    msg = {"from": numero, "id": wamid, "timestamp": "1", "type": tipo}
    if tipo == "text":
        msg["text"] = {"body": texto}
    return {"object": "whatsapp_business_account", "entry": [{"id": "1", "changes": [{"field": "messages", "value": {
        "messaging_product": "whatsapp", "metadata": {"display_phone_number": "1", "phone_number_id": "PID"},
        "contacts": [{"profile": {"name": "Marcos"}, "wa_id": numero}], "messages": [msg]}}]}]}


def firma(cuerpo):
    return "sha256=" + hmac.new(b"secreto", cuerpo, hashlib.sha256).hexdigest()


class Base(unittest.TestCase):
    def setUp(self):
        self.dir = tempfile.mkdtemp()
        shutil.copy(os.path.join(AQUI, "agenda.json"), self.dir)
        self.agenda = Agenda(os.path.join(self.dir, "agenda.json"))
        self.mem = Memoria(os.path.join(self.dir, "m.db"))

    def tearDown(self):
        self.mem.db.close()
        shutil.rmtree(self.dir, ignore_errors=True)


class TestMeta(unittest.TestCase):
    def test_reto_correcto(self):
        self.assertEqual(meta.verificar({"hub.mode": "subscribe", "hub.verify_token": "tok", "hub.challenge": "1158"}, "tok"),
                         (200, "1158"))

    def test_reto_token_malo(self):
        self.assertEqual(meta.verificar({"hub.mode": "subscribe", "hub.verify_token": "otro", "hub.challenge": "1"}, "tok")[0], 403)

    def test_reto_sin_token_configurado(self):
        self.assertEqual(meta.verificar({"hub.mode": "subscribe", "hub.verify_token": "", "hub.challenge": "1"}, "")[0], 403)

    def test_firma(self):
        c = b'{"a":1}'
        self.assertTrue(meta.firma_valida(c, firma(c), "secreto"))
        self.assertFalse(meta.firma_valida(c, "sha256=00", "secreto"))
        self.assertFalse(meta.firma_valida(c, None, "secreto"))

    def test_extraer_texto_y_estados(self):
        ms = meta.extraer_mensajes(payload("Hola"))
        self.assertEqual(ms[0]["texto"], "Hola")
        self.assertEqual(ms[0]["numero"], "34600000000")
        self.assertEqual(ms[0]["phone_number_id"], "PID")
        estado = {"object": "whatsapp_business_account", "entry": [{"changes": [{"value": {"statuses": [{"id": "x"}]}}]}]}
        self.assertEqual(meta.extraer_mensajes(estado), [])
        self.assertEqual(meta.extraer_mensajes({"object": "page"}), [])

    def test_enviar_texto_forma_de_la_peticion(self):
        visto = {}

        def falso(url, cab, cuerpo):
            visto.update(url=url, cab=cab, cuerpo=cuerpo)
            return {}
        meta.enviar_texto("PID", "34600000000", "hola", CFG, post=falso)
        self.assertEqual(visto["url"], "https://graph.facebook.com/v27.0/PID/messages")
        self.assertEqual(visto["cab"]["Authorization"], "Bearer t")
        self.assertEqual(visto["cuerpo"]["messaging_product"], "whatsapp")
        self.assertEqual(visto["cuerpo"]["text"]["body"], "hola")


class TestMemoria(Base):
    def test_ultimos_20_por_numero(self):
        for i in range(30):
            self.mem.anadir("A", "user", f"m{i}")
        self.mem.anadir("B", "user", "otro")
        h = self.mem.ultimos("A")
        self.assertEqual(len(h), 20)
        self.assertEqual(h[0]["content"], "m10")
        self.assertEqual(h[-1]["content"], "m29")
        self.assertEqual(len(self.mem.ultimos("B")), 1)

    def test_duplicados(self):
        self.assertFalse(self.mem.ya_visto("w1"))
        self.assertTrue(self.mem.ya_visto("w1"))


class TestAgenda(Base):
    def test_huecos(self):
        self.assertIn("10:00", self.agenda.ver_huecos("2026-12-01"))
        self.assertEqual(self.agenda.ver_huecos("2030-01-01"), [])

    def test_no_reserva_sin_propuesta(self):
        self.assertFalse(self.agenda.confirmar_reserva("A", 5)["ok"])

    def test_no_reserva_en_el_mismo_turno(self):
        self.agenda.proponer_reserva("A", "2026-12-01", "10:00", "Marcos", "Corte", turno=1)
        self.assertFalse(self.agenda.confirmar_reserva("A", 1)["ok"])
        self.assertIn("10:00", self.agenda.ver_huecos("2026-12-01"))

    def test_reserva_tras_confirmar(self):
        self.agenda.proponer_reserva("A", "2026-12-01", "10:00", "Marcos", "Corte", turno=1)
        self.assertTrue(self.agenda.confirmar_reserva("A", 2)["ok"])
        self.assertNotIn("10:00", self.agenda.ver_huecos("2026-12-01"))
        self.assertFalse(self.agenda.proponer_reserva("B", "2026-12-01", "10:00", "Ana", "Corte", 1)["ok"])
        with open(self.agenda.ruta, encoding="utf-8") as f:
            self.assertEqual(json.load(f)["reservas"][0]["nombre"], "Marcos")


def modelo_guion(pasos, registro):
    """Modelo falso: devuelve los mensajes de 'pasos' uno a uno y guarda lo que recibe."""
    it = iter(pasos)

    def completar(mensajes, herramientas, cfg):
        registro.append([dict(m) for m in mensajes])
        return next(it)
    return completar


def llamada(nombre, args, id_="c1"):
    return {"role": "assistant", "content": None,
            "tool_calls": [{"id": id_, "type": "function", "function": {"name": nombre, "arguments": json.dumps(args)}}]}


class TestAgente(Base):
    def crear(self, pasos, registro):
        negocio = ag.cargar_negocio(os.path.join(AQUI, "negocio.json"))
        return ag.Agente(self.mem, self.agenda, negocio, CFG, completar=modelo_guion(pasos, registro))

    def test_prompt_lee_la_ficha_y_prohibe_inventar(self):
        negocio = ag.cargar_negocio(os.path.join(AQUI, "negocio.json"))
        p = ag.prompt_sistema(negocio)
        self.assertIn("Barberia Norte", p)
        self.assertIn("Corte de pelo", p)
        self.assertIn("Nunca inventes", p)
        self.assertIn("confirmar_reserva", p)

    def test_respuesta_simple_y_memoria(self):
        reg = []
        a = self.crear([{"role": "assistant", "content": "Hola, dime."}, {"role": "assistant", "content": "Claro."}], reg)
        self.assertEqual(a.responder("A", "hola"), "Hola, dime.")
        a.responder("A", "otra cosa")
        # En la 2a llamada el modelo recibe system + hola + respuesta + otra cosa
        roles = [m["role"] for m in reg[1]]
        self.assertEqual(roles, ["system", "user", "assistant", "user"])

    def test_solo_20_mensajes_al_modelo(self):
        reg = []
        a = self.crear([{"role": "assistant", "content": "ok"}], reg)
        for i in range(40):
            self.mem.anadir("A", "user", f"viejo{i}")
        a.responder("A", "nuevo")
        self.assertEqual(len(reg[0]), 21)  # system + 20

    def test_flujo_reserva_con_confirmacion(self):
        reg = []
        a = self.crear([
            llamada("ver_huecos", {"fecha": "2026-12-01"}),
            {"role": "assistant", "content": "Hay 10:00 y 10:30."},
            llamada("proponer_reserva", {"fecha": "2026-12-01", "hora": "10:00", "nombre": "Marcos", "servicio": "Corte de pelo"}),
            {"role": "assistant", "content": "Corte el 1/12 a las 10:00 a nombre de Marcos. Confirmas?"},
            llamada("confirmar_reserva", {}),
            {"role": "assistant", "content": "Hecho, te esperamos."},
        ], reg)
        a.responder("A", "quiero cita el martes 1")
        a.responder("A", "a las 10, soy Marcos, corte")
        self.assertIn("10:00", self.agenda.ver_huecos("2026-12-01"))  # aun NO reservado
        out = a.responder("A", "si, confirmo")
        self.assertEqual(out, "Hecho, te esperamos.")
        self.assertNotIn("10:00", self.agenda.ver_huecos("2026-12-01"))

    def test_modelo_que_intenta_reservar_sin_esperar_al_cliente(self):
        reg = []
        a = self.crear([
            llamada("proponer_reserva", {"fecha": "2026-12-01", "hora": "10:00", "nombre": "M", "servicio": "Corte"}, "c1"),
            llamada("confirmar_reserva", {}, "c2"),
            {"role": "assistant", "content": "Confirmas?"},
        ], reg)
        a.responder("A", "cita a las 10")
        self.assertIn("10:00", self.agenda.ver_huecos("2026-12-01"))  # el codigo lo impidio
        self.assertEqual(self.agenda.pendientes["A"]["hora"], "10:00")

    def test_herramienta_con_argumentos_malos_no_rompe(self):
        reg = []
        a = self.crear([llamada("proponer_reserva", {"fecha": "2026-12-01"}), {"role": "assistant", "content": "Que hora?"}], reg)
        self.assertEqual(a.responder("A", "cita"), "Que hora?")

    def test_si_falla_el_modelo_hay_respuesta_de_respaldo(self):
        def roto(m, h, c):
            raise urllib.error.URLError("sin red")
        a = ag.Agente(self.mem, self.agenda, {"nombre": "x"}, CFG, completar=roto)
        self.assertEqual(a.responder("A", "hola"), ag.RESPALDO)


class TestServidor(Base):
    def arrancar(self, enviados, respuesta="Hola!"):
        class Falso:
            def responder(self, numero, texto):
                return respuesta + " " + texto

        def enviar(pid, destino, texto, cfg):
            enviados.append((pid, destino, texto))
        srv = servidor.crear_servidor(CFG, Falso(), self.mem, puerto=0, en_segundo_plano=False, enviar=enviar)
        threading.Thread(target=srv.serve_forever, daemon=True).start()
        self.addCleanup(srv.server_close)  # se ejecuta el ultimo
        self.addCleanup(srv.shutdown)
        return f"http://127.0.0.1:{srv.server_address[1]}"

    def get(self, url):
        try:
            with urllib.request.urlopen(url) as r:
                return r.status, r.read().decode()
        except urllib.error.HTTPError as e:
            return e.code, e.read().decode()

    def post(self, url, cuerpo, cab):
        req = urllib.request.Request(url, data=cuerpo, headers=cab, method="POST")
        try:
            with urllib.request.urlopen(req) as r:
                return r.status
        except urllib.error.HTTPError as e:
            return e.code

    def test_reto_de_verificacion(self):
        base = self.arrancar([])
        self.assertEqual(self.get(base + "/webhook?hub.mode=subscribe&hub.challenge=1158201444&hub.verify_token=tok"),
                         (200, "1158201444"))
        self.assertEqual(self.get(base + "/webhook?hub.mode=subscribe&hub.challenge=1&hub.verify_token=mal")[0], 403)
        self.assertEqual(self.get(base + "/salud"), (200, "ok"))

    def test_post_firmado_contesta_y_no_duplica(self):
        env = []
        base = self.arrancar(env)
        c = json.dumps(payload("precio?")).encode()
        cab = {"Content-Type": "application/json", "X-Hub-Signature-256": firma(c)}
        self.assertEqual(self.post(base + "/webhook", c, cab), 200)
        self.assertEqual(self.post(base + "/webhook", c, cab), 200)  # reintento de Meta
        self.assertEqual(env, [("PID", "34600000000", "Hola! precio?")])

    def test_post_sin_firma_correcta_se_rechaza(self):
        env = []
        base = self.arrancar(env)
        c = json.dumps(payload()).encode()
        self.assertEqual(self.post(base + "/webhook", c, {"X-Hub-Signature-256": "sha256=00"}), 403)
        self.assertEqual(self.post(base + "/webhook", c, {}), 403)
        self.assertEqual(env, [])

    def test_mensaje_no_texto(self):
        env = []
        base = self.arrancar(env)
        c = json.dumps(payload(tipo="image", wamid="wamid.img")).encode()
        self.post(base + "/webhook", c, {"X-Hub-Signature-256": firma(c)})
        self.assertIn("solo puedo leer", env[0][2])


if __name__ == "__main__":
    unittest.main()
