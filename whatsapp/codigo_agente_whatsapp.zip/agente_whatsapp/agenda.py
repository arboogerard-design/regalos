"""agenda.py - Agenda sencilla sobre agenda.json.
Herramientas para el modelo:
  ver_huecos(fecha)            -> lista de horas libres ese dia
  proponer_reserva(...)        -> NO reserva: apunta una propuesta pendiente y devuelve el resumen
  confirmar_reserva(numero)    -> reserva SOLO si hay propuesta y el cliente ha escrito OTRO mensaje despues
Asi la confirmacion la impone el codigo, no solo el prompt.
Prueba: tests/test_agenda.py
"""
import json
import threading


class Agenda:
    def __init__(self, ruta="agenda.json"):
        self.ruta = ruta
        self.lock = threading.Lock()
        self.pendientes = {}  # numero -> propuesta

    def _leer(self):
        with open(self.ruta, encoding="utf-8") as f:
            return json.load(f)

    def _guardar(self, datos):
        with open(self.ruta, "w", encoding="utf-8") as f:
            json.dump(datos, f, ensure_ascii=False, indent=2)

    def ver_huecos(self, fecha):
        with self.lock:
            return list(self._leer().get("libres", {}).get(fecha, []))

    def proponer_reserva(self, numero, fecha, hora, nombre, servicio, turno):
        with self.lock:
            libres = self._leer().get("libres", {}).get(fecha, [])
            if hora not in libres:
                return {"ok": False, "error": "ese hueco no esta libre", "libres": libres}
            self.pendientes[numero] = {"fecha": fecha, "hora": hora, "nombre": nombre,
                                       "servicio": servicio, "turno": turno}
            return {"ok": True, "estado": "pendiente_de_confirmacion",
                    "resumen": f"{servicio} el {fecha} a las {hora} a nombre de {nombre}",
                    "instruccion": "Pide al cliente que confirme con un si y espera su respuesta. No hay reserva todavia."}

    def confirmar_reserva(self, numero, turno_actual):
        with self.lock:
            p = self.pendientes.get(numero)
            if not p:
                return {"ok": False, "error": "no hay ninguna propuesta pendiente; usa proponer_reserva primero"}
            if turno_actual <= p["turno"]:
                return {"ok": False, "error": "el cliente aun no ha confirmado: pregunta y espera su respuesta"}
            datos = self._leer()
            libres = datos.setdefault("libres", {}).get(p["fecha"], [])
            if p["hora"] not in libres:
                del self.pendientes[numero]
                return {"ok": False, "error": "el hueco se acaba de ocupar"}
            libres.remove(p["hora"])
            datos.setdefault("reservas", []).append(
                {"numero": numero, "fecha": p["fecha"], "hora": p["hora"], "nombre": p["nombre"], "servicio": p["servicio"]})
            self._guardar(datos)
            del self.pendientes[numero]
            return {"ok": True, "reserva": f"{p['servicio']} el {p['fecha']} a las {p['hora']} a nombre de {p['nombre']}"}
