"""meta.py - WhatsApp Cloud API (Meta).
- verificar(): responde al reto GET (hub.mode / hub.verify_token / hub.challenge)
- firma_valida(): comprueba X-Hub-Signature-256 (HMAC SHA256 con el App Secret)
- extraer_mensajes(): saca los textos entrantes del POST (entry[].changes[].value.messages[])
- enviar_texto(): POST https://graph.facebook.com/<version>/<phone_number_id>/messages
Prueba: tests/test_meta.py
"""
import hashlib
import hmac
import json
import urllib.request


def verificar(query, verify_token):
    """query: dict con 'hub.mode', 'hub.verify_token', 'hub.challenge'. Devuelve (estado, cuerpo)."""
    if query.get("hub.mode") == "subscribe" and verify_token and query.get("hub.verify_token") == verify_token:
        return 200, query.get("hub.challenge", "")
    return 403, "token incorrecto"


def firma_valida(cuerpo_bytes, cabecera, app_secret):
    if not cabecera or not cabecera.startswith("sha256=") or not app_secret:
        return False
    esperado = hmac.new(app_secret.encode("utf-8"), cuerpo_bytes, hashlib.sha256).hexdigest()
    return hmac.compare_digest(esperado, cabecera[len("sha256="):])


def extraer_mensajes(payload):
    """Lista de dicts {id, numero, tipo, texto, phone_number_id, nombre}. Ignora 'statuses'."""
    salida = []
    if payload.get("object") != "whatsapp_business_account":
        return salida
    for entrada in payload.get("entry", []):
        for cambio in entrada.get("changes", []):
            v = cambio.get("value", {})
            pid = v.get("metadata", {}).get("phone_number_id", "")
            nombres = {c.get("wa_id"): c.get("profile", {}).get("name", "") for c in v.get("contacts", [])}
            for m in v.get("messages", []):
                numero = m.get("from") or m.get("from_user_id") or ""
                es_texto = m.get("type") == "text"
                salida.append({"id": m.get("id", ""), "numero": numero, "tipo": m.get("type", ""),
                               "texto": m.get("text", {}).get("body", "") if es_texto else "",
                               "phone_number_id": pid, "nombre": nombres.get(numero, "")})
    return salida


def post_json(url, headers, cuerpo, timeout=30):
    req = urllib.request.Request(url, data=json.dumps(cuerpo).encode("utf-8"), headers=headers, method="POST")
    with urllib.request.urlopen(req, timeout=timeout) as r:
        return json.loads(r.read().decode("utf-8"))


def enviar_texto(phone_number_id, destino, texto, cfg, post=post_json):
    url = f"https://graph.facebook.com/{cfg['GRAPH_VERSION']}/{phone_number_id}/messages"
    cab = {"Content-Type": "application/json", "Authorization": "Bearer " + cfg["WHATSAPP_TOKEN"]}
    cuerpo = {"messaging_product": "whatsapp", "recipient_type": "individual", "to": destino,
              "type": "text", "text": {"body": texto}}
    return post(url, cab, cuerpo)
