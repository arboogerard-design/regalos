# Agente de WhatsApp (Clipeya) - proyecto minimo

Responde por WhatsApp Cloud API usando un modelo de OpenRouter. Python 3.9 o superior, **sin instalar nada** (solo la libreria estandar).

## Que hace
- `servidor.py`: webhook. `GET /webhook` (reto de verificacion de Meta), `POST /webhook` (mensajes; valida la firma `X-Hub-Signature-256`), `GET /salud`.
- `agente.py`: construye el prompt de sistema leyendo `negocio.json`, manda los ultimos 20 mensajes al modelo y gestiona las herramientas de agenda.
- `memoria.py`: SQLite (`memoria.db`), ultimos 20 mensajes por numero. Ignora mensajes repetidos (Meta reintenta).
- `agenda.py` + `agenda.json`: `ver_huecos`, `proponer_reserva`, `confirmar_reserva`. **Solo reserva si el cliente ha escrito otro mensaje despues de la propuesta** (lo impone el codigo, no solo el prompt).
- `llm.py` (OpenRouter) y `meta.py` (WhatsApp).

## Puesta en marcha
1. Copia `.env.example` como `.env` y rellena tus claves. **Nunca compartas `.env`.**
2. Edita `negocio.json` (tus datos reales; los de ejemplo estan marcados EJEMPLO) y `agenda.json`.
3. Comprueba que todo va, sin red ni claves: `python -m unittest discover -s tests -v`
4. Arranca: `python servidor.py`
5. Comprueba el reto: `curl "http://localhost:8000/webhook?hub.mode=subscribe&hub.verify_token=TU_VERIFY_TOKEN&hub.challenge=123"` debe devolver `123`.
6. Para que Meta te vea necesitas una direccion publica con HTTPS (un servidor o un tunel, ver la guia, paso 8) y ponerla en el panel de Meta como URL de devolucion de llamada: `https://TU-DOMINIO/webhook`.

## Limites conocidos (version minima)
- Solo mensajes de texto (a imagenes y audios responde que solo lee texto).
- Una agenda en un fichero JSON: sirve para empezar; con mucho volumen usa una agenda real.
- Meta solo permite respuestas libres durante las 24 h siguientes al ultimo mensaje del cliente.
- Si el modelo falla, el cliente recibe un mensaje de disculpa y el error queda en la consola.
