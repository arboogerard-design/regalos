"""servidor.py - Webhook de WhatsApp Cloud API.
GET  /webhook  -> reto de verificacion de Meta (devuelve hub.challenge si el token coincide)
POST /webhook  -> mensajes entrantes: valida firma, contesta 200 enseguida y procesa en segundo plano
GET  /salud    -> "ok" (para comprobar que sigue en linea)
Arranque: python servidor.py   (lee .env)
Prueba: tests/test_servidor.py
"""
import json
import threading
from http.server import BaseHTTPRequestHandler, ThreadingHTTPServer
from urllib.parse import parse_qs, urlparse

import config
import meta
from agente import Agente, cargar_negocio
from agenda import Agenda
from memoria import Memoria

SIN_TEXTO = "Por ahora solo puedo leer mensajes de texto. Escribeme lo que necesitas y te ayudo."


def procesar(payload, agente, memoria, cfg, enviar=meta.enviar_texto):
    """Contesta a cada mensaje nuevo del payload. Devuelve cuantos ha contestado."""
    n = 0
    for m in meta.extraer_mensajes(payload):
        if not m["numero"] or memoria.ya_visto(m["id"]):
            continue
        texto = agente.responder(m["numero"], m["texto"]) if m["tipo"] == "text" and m["texto"] else SIN_TEXTO
        try:
            enviar(m["phone_number_id"], m["numero"], texto, cfg)
            n += 1
        except Exception as e:
            print("ERROR enviando a Meta:", type(e).__name__, e)
    return n


def crear_servidor(cfg, agente, memoria, puerto=None, en_segundo_plano=True, enviar=meta.enviar_texto):
    class Manejador(BaseHTTPRequestHandler):
        def _responder(self, codigo, cuerpo):
            datos = cuerpo.encode("utf-8")
            self.send_response(codigo)
            self.send_header("Content-Type", "text/plain; charset=utf-8")
            self.send_header("Content-Length", str(len(datos)))
            self.end_headers()
            self.wfile.write(datos)

        def do_GET(self):
            url = urlparse(self.path)
            if url.path == "/salud":
                return self._responder(200, "ok")
            if url.path == "/webhook":
                q = {k: v[0] for k, v in parse_qs(url.query).items()}
                codigo, cuerpo = meta.verificar(q, cfg["VERIFY_TOKEN"])
                return self._responder(codigo, cuerpo)
            self._responder(404, "no encontrado")

        def do_POST(self):
            if urlparse(self.path).path != "/webhook":
                return self._responder(404, "no encontrado")
            largo = int(self.headers.get("Content-Length") or 0)
            cuerpo = self.rfile.read(largo)
            if cfg["APP_SECRET"] and not meta.firma_valida(cuerpo, self.headers.get("X-Hub-Signature-256"), cfg["APP_SECRET"]):
                return self._responder(403, "firma incorrecta")
            try:
                payload = json.loads(cuerpo.decode("utf-8"))
            except ValueError:
                return self._responder(400, "json incorrecto")
            if en_segundo_plano:
                threading.Thread(target=procesar, args=(payload, agente, memoria, cfg, enviar), daemon=True).start()
            else:
                procesar(payload, agente, memoria, cfg, enviar)
            self._responder(200, "ok")

        def log_message(self, *a):
            pass

    return ThreadingHTTPServer(("0.0.0.0", int(puerto if puerto is not None else cfg["PORT"])), Manejador)


def main():
    cfg = config.cargar()
    faltan = [k for k in ("VERIFY_TOKEN", "WHATSAPP_TOKEN", "OPENROUTER_API_KEY") if not cfg[k]]
    if faltan:
        raise SystemExit("Faltan en .env: " + ", ".join(faltan))
    if not cfg["APP_SECRET"]:
        print("AVISO: sin APP_SECRET no se comprueba la firma de Meta. Pon el App Secret en .env.")
    memoria = Memoria("memoria.db")
    agente = Agente(memoria, Agenda("agenda.json"), cargar_negocio("negocio.json"), cfg)
    srv = crear_servidor(cfg, agente, memoria)
    print(f"Escuchando en el puerto {srv.server_address[1]} (webhook: /webhook, salud: /salud)")
    srv.serve_forever()


if __name__ == "__main__":
    main()
