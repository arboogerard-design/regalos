"""config.py - Lee la configuracion de .env (sin librerias externas).
Entra: fichero .env (o variables de entorno). Sale: dict con los ajustes.
Prueba: python -m unittest discover -s tests
"""
import os

CLAVES = ["VERIFY_TOKEN", "APP_SECRET", "WHATSAPP_TOKEN", "OPENROUTER_API_KEY",
          "OPENROUTER_MODEL", "PORT", "GRAPH_VERSION"]
DEFECTOS = {"OPENROUTER_MODEL": "anthropic/claude-sonnet-4.5", "PORT": "8000",
            "GRAPH_VERSION": "v27.0"}


def cargar(ruta=".env"):
    datos = {}
    if os.path.exists(ruta):
        with open(ruta, encoding="utf-8") as f:
            for linea in f:
                linea = linea.strip()
                if not linea or linea.startswith("#") or "=" not in linea:
                    continue
                k, v = linea.split("=", 1)
                datos[k.strip()] = v.strip().strip('"').strip("'")
    cfg = {}
    for k in CLAVES:
        cfg[k] = os.environ.get(k) or datos.get(k) or DEFECTOS.get(k, "")
    return cfg
